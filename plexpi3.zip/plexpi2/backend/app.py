#!/usr/bin/env python3
"""
PlexPi - Raspberry Pi 5 Plex Music Player Backend
"""

import os
import json
import time
import threading
import subprocess
from pathlib import Path
from flask import Flask, jsonify, request, Response, stream_with_context
from flask_cors import CORS
from plexapi.server import PlexServer
from plexapi.myplex import MyPlexAccount
import requests as http_requests

app = Flask(__name__)
CORS(app)

# ── Config ────────────────────────────────────────────────────────────────────
CONFIG_FILE = Path(os.path.expanduser("~/.plexpi/config.json"))

def load_config():
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {}

def save_config(cfg):
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)

# ── Plex connection ───────────────────────────────────────────────────────────
_plex = None
_plex_lock = threading.Lock()

def get_plex():
    global _plex
    with _plex_lock:
        if _plex is not None:
            return _plex
        cfg = load_config()
        if not cfg.get("plex_url") or not cfg.get("plex_token"):
            return None
        try:
            _plex = PlexServer(cfg["plex_url"], cfg["plex_token"], timeout=10)
            return _plex
        except Exception as e:
            print(f"Plex connection error: {e}")
            return None

def reset_plex():
    global _plex
    with _plex_lock:
        _plex = None

# ── Player state ──────────────────────────────────────────────────────────────
player_state = {
    "status": "stopped",
    "source": "plex",
    "track": None,
    "artist": None,
    "album": None,
    "album_art_url": None,
    "duration": 0,
    "position": 0,
    "volume": 80,
    "queue": [],
    "queue_index": 0,
    "shuffle": False,
    "repeat": "none",
}
state_lock = threading.Lock()
mpv_proc = None
MPV_SOCKET = "/tmp/plexpi-mpv.sock"

# ── MPV control ───────────────────────────────────────────────────────────────
def mpv_cmd(cmd):
    try:
        payload = json.dumps({"command": cmd}) + "\n"
        r = subprocess.run(
            ["socat", "-", f"UNIX-CONNECT:{MPV_SOCKET}"],
            input=payload.encode(), capture_output=True, timeout=2
        )
        if r.stdout:
            lines = r.stdout.decode().strip().split("\n")
            return json.loads(lines[0])
    except Exception:
        pass
    return None

def mpv_get(prop):
    r = mpv_cmd(["get_property", prop])
    if r and r.get("error") == "success":
        return r.get("data")
    return None

def mpv_set(prop, val):
    mpv_cmd(["set_property", prop, val])

def mpv_start(url):
    global mpv_proc
    mpv_stop()
    time.sleep(0.3)
    cmd = [
        "mpv", "--no-video",
        f"--input-ipc-server={MPV_SOCKET}",
        "--really-quiet",
        f"--volume={player_state['volume']}",
        url
    ]
    mpv_proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def mpv_stop():
    global mpv_proc
    if mpv_proc:
        try:
            mpv_proc.terminate()
            mpv_proc.wait(timeout=3)
        except Exception:
            try:
                mpv_proc.kill()
            except Exception:
                pass
        mpv_proc = None

def play_index(idx):
    with state_lock:
        q = player_state["queue"]
        if not q or idx < 0 or idx >= len(q):
            return
        item = q[idx]
        cfg = load_config()
        url = f"{cfg['plex_url']}{item['stream_key']}?X-Plex-Token={cfg['plex_token']}"
        player_state.update({
            "status": "playing",
            "source": "plex",
            "track": item["title"],
            "artist": item["artist"],
            "album": item["album"],
            "album_art_url": item.get("thumb_url"),
            "duration": item.get("duration", 0),
            "position": 0,
            "queue_index": idx,
        })
    mpv_start(url)

def advance(direction=1):
    with state_lock:
        q = player_state["queue"]
        if not q:
            player_state["status"] = "stopped"
            return
        idx = player_state["queue_index"] + direction
        if player_state["repeat"] == "all":
            idx = idx % len(q)
        elif idx >= len(q) or idx < 0:
            player_state["status"] = "stopped"
            return
        player_state["queue_index"] = idx
    play_index(idx)

def position_tracker():
    while True:
        time.sleep(1)
        if player_state["status"] == "playing" and player_state["source"] == "plex":
            pos = mpv_get("time-pos")
            if pos is not None:
                with state_lock:
                    player_state["position"] = int(pos)
            elif mpv_proc and mpv_proc.poll() is not None:
                if player_state["repeat"] == "one":
                    play_index(player_state["queue_index"])
                else:
                    advance(1)

threading.Thread(target=position_tracker, daemon=True).start()

# ── Helpers ───────────────────────────────────────────────────────────────────
def track_to_dict(track, base_url, token):
    media = track.media[0] if track.media else None
    stream_key = media.parts[0].key if (media and media.parts) else None
    raw_thumb = track.thumb or (track.parentThumb if hasattr(track, "parentThumb") else None)
    thumb = f"{base_url}{raw_thumb}?X-Plex-Token={token}" if raw_thumb else None
    return {
        "key": track.key,
        "title": track.title,
        "track_number": getattr(track, "trackNumber", None),
        "duration": int(track.duration / 1000) if track.duration else 0,
        "artist": track.grandparentTitle,
        "album": track.parentTitle,
        "thumb_url": thumb,
        "stream_key": stream_key,
    }

# ── API: Config / Connect ─────────────────────────────────────────────────────
@app.route("/api/config", methods=["GET", "POST"])
def config():
    if request.method == "POST":
        cfg = load_config()
        cfg.update(request.json)
        save_config(cfg)
        reset_plex()
        return jsonify({"ok": True})
    cfg = load_config()
    return jsonify({"configured": bool(cfg.get("plex_token")), "server_name": cfg.get("server_name", "")})

@app.route("/api/connect", methods=["POST"])
def connect():
    data = request.json or {}
    try:
        if data.get("url") and data.get("token"):
            plex = PlexServer(data["url"], data["token"], timeout=10)
            cfg = load_config()
            cfg.update({"plex_url": data["url"], "plex_token": data["token"], "server_name": plex.friendlyName})
            save_config(cfg)
            reset_plex()
            return jsonify({"ok": True, "server": plex.friendlyName})
        elif data.get("username") and data.get("password"):
            account = MyPlexAccount(data["username"], data["password"])
            servers = [r for r in account.resources() if r.provides == "server"]
            if not servers:
                return jsonify({"error": "No Plex servers found on this account"}), 400
            server = servers[0].connect()
            cfg = load_config()
            cfg.update({
                "plex_url": server._baseurl,
                "plex_token": account.authenticationToken,
                "server_name": servers[0].name,
            })
            save_config(cfg)
            reset_plex()
            return jsonify({"ok": True, "server": servers[0].name})
        else:
            return jsonify({"error": "Provide url+token or username+password"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# ── API: Library ──────────────────────────────────────────────────────────────
@app.route("/api/libraries")
def libraries():
    plex = get_plex()
    if not plex:
        return jsonify({"error": "Not connected to Plex"}), 503
    try:
        return jsonify([
            {"key": s.key, "title": s.title}
            for s in plex.library.sections() if s.type == "artist"
        ])
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/library/<int:key>/artists")
def artists(key):
    plex = get_plex()
    if not plex:
        return jsonify({"error": "Not connected"}), 503
    try:
        cfg = load_config()
        base, token = cfg["plex_url"], cfg["plex_token"]
        section = plex.library.sectionByID(key)
        return jsonify([
            {"key": a.key, "title": a.title,
             "thumb_url": f"{base}{a.thumb}?X-Plex-Token={token}" if a.thumb else None}
            for a in section.all()
        ])
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/artist/albums")
def artist_albums():
    plex = get_plex()
    if not plex:
        return jsonify({"error": "Not connected"}), 503
    key = request.args.get("key")
    try:
        cfg = load_config()
        base, token = cfg["plex_url"], cfg["plex_token"]
        artist = plex.fetchItem(key)
        return jsonify([
            {"key": al.key, "title": al.title, "year": al.year,
             "artist": artist.title,
             "thumb_url": f"{base}{al.thumb}?X-Plex-Token={token}" if al.thumb else None}
            for al in artist.albums()
        ])
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/album/tracks")
def album_tracks():
    plex = get_plex()
    if not plex:
        return jsonify({"error": "Not connected"}), 503
    key = request.args.get("key")
    try:
        cfg = load_config()
        base, token = cfg["plex_url"], cfg["plex_token"]
        album = plex.fetchItem(key)
        thumb = f"{base}{album.thumb}?X-Plex-Token={token}" if album.thumb else None
        tracks = []
        for t in album.tracks():
            d = track_to_dict(t, base, token)
            d["thumb_url"] = thumb
            tracks.append(d)
        return jsonify({"tracks": tracks, "album_art": thumb, "album_title": album.title, "artist": album.parentTitle})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/playlists")
def playlists():
    plex = get_plex()
    if not plex:
        return jsonify({"error": "Not connected"}), 503
    try:
        cfg = load_config()
        base, token = cfg["plex_url"], cfg["plex_token"]
        return jsonify([
            {"key": p.key, "title": p.title, "count": p.leafCount,
             "thumb_url": f"{base}{p.composite}?X-Plex-Token={token}" if p.composite else None}
            for p in plex.playlists() if p.playlistType == "audio"
        ])
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/playlist/tracks")
def playlist_tracks():
    plex = get_plex()
    if not plex:
        return jsonify({"error": "Not connected"}), 503
    key = request.args.get("key")
    try:
        cfg = load_config()
        base, token = cfg["plex_url"], cfg["plex_token"]
        pl = plex.fetchItem(key)
        return jsonify([track_to_dict(t, base, token) for t in pl.items()])
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/search")
def search():
    plex = get_plex()
    if not plex:
        return jsonify({"error": "Not connected"}), 503
    q = request.args.get("q", "").strip()
    if not q:
        return jsonify([])
    try:
        cfg = load_config()
        base, token = cfg["plex_url"], cfg["plex_token"]
        return jsonify([track_to_dict(t, base, token) for t in plex.search(q, mediatype="track", limit=30)])
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── API: Playback ─────────────────────────────────────────────────────────────
@app.route("/api/player/play", methods=["POST"])
def play():
    data = request.json or {}
    tracks = data.get("tracks")
    if tracks is not None:
        idx = data.get("index", 0)
        with state_lock:
            player_state["queue"] = tracks
        play_index(idx)
    else:
        if player_state["status"] == "paused":
            mpv_set("pause", False)
            with state_lock:
                player_state["status"] = "playing"
    return jsonify(player_state)

@app.route("/api/player/pause", methods=["POST"])
def pause():
    mpv_set("pause", True)
    with state_lock:
        player_state["status"] = "paused"
    return jsonify(player_state)

@app.route("/api/player/stop", methods=["POST"])
def stop():
    mpv_stop()
    with state_lock:
        player_state.update({"status": "stopped", "position": 0})
    return jsonify(player_state)

@app.route("/api/player/next", methods=["POST"])
def next_track():
    advance(1)
    return jsonify(player_state)

@app.route("/api/player/prev", methods=["POST"])
def prev_track():
    if player_state["position"] > 3:
        mpv_cmd(["seek", 0, "absolute"])
        with state_lock:
            player_state["position"] = 0
    else:
        advance(-1)
    return jsonify(player_state)

@app.route("/api/player/seek", methods=["POST"])
def seek():
    pos = request.json.get("position", 0)
    mpv_cmd(["seek", pos, "absolute"])
    with state_lock:
        player_state["position"] = int(pos)
    return jsonify(player_state)

@app.route("/api/player/volume", methods=["POST"])
def volume():
    vol = max(0, min(100, int(request.json.get("volume", 80))))
    mpv_set("volume", vol)
    subprocess.run(["amixer", "sset", "Master", f"{vol}%"], capture_output=True)
    with state_lock:
        player_state["volume"] = vol
    return jsonify(player_state)

@app.route("/api/player/shuffle", methods=["POST"])
def shuffle():
    import random
    with state_lock:
        player_state["shuffle"] = not player_state["shuffle"]
        if player_state["shuffle"] and player_state["queue"]:
            cur = player_state["queue"][player_state["queue_index"]]
            random.shuffle(player_state["queue"])
            player_state["queue_index"] = player_state["queue"].index(cur)
    return jsonify(player_state)

@app.route("/api/player/repeat", methods=["POST"])
def repeat():
    modes = ["none", "all", "one"]
    with state_lock:
        cur = player_state["repeat"]
        player_state["repeat"] = modes[(modes.index(cur) + 1) % len(modes)]
    return jsonify(player_state)

@app.route("/api/player/state")
def state():
    return jsonify(player_state)

@app.route("/api/player/events")
def events():
    def generate():
        last = ""
        while True:
            s = json.dumps(player_state)
            if s != last:
                yield f"data: {s}\n\n"
                last = s
            time.sleep(0.5)
    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )

@app.route("/api/proxy/art")
def proxy_art():
    url = request.args.get("url", "")
    if not url:
        return "", 404
    try:
        cfg = load_config()
        if "X-Plex-Token" not in url:
            url += f"&X-Plex-Token={cfg.get('plex_token','')}"
        r = http_requests.get(url, stream=True, timeout=5)
        return Response(r.iter_content(8192), content_type=r.headers.get("content-type", "image/jpeg"))
    except Exception as e:
        return str(e), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, threaded=True)
