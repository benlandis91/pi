#!/bin/bash
# PlexPi - Fresh install script for Raspberry Pi 5 + Pi OS Lite (64-bit)
# Run as: sudo bash setup.sh

set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log()  { echo -e "${GREEN}[✓]${NC} $1"; }
info() { echo -e "${BLUE}[→]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
err()  { echo -e "${RED}[✗] ERROR: $1${NC}"; exit 1; }

[[ $EUID -ne 0 ]] && err "Run as root: sudo bash setup.sh"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PLEXPI_DIR="/opt/plexpi"
PI_USER="${SUDO_USER:-pi}"
PI_HOME="/home/${PI_USER}"

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║     PlexPi Setup - Pi 5 + Pi OS Lite    ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
echo ""
info "Installing for user: ${PI_USER}"
echo ""

# ── 1. Update ─────────────────────────────────────────────────────────────────
info "Updating package lists..."
apt-get update -qq
apt-get install -y --no-install-recommends \
  ca-certificates curl wget git 2>/dev/null
log "Package lists updated"

# ── 2. Display / Kiosk packages ───────────────────────────────────────────────
info "Installing display packages..."
apt-get install -y --no-install-recommends \
  xserver-xorg \
  xserver-xorg-video-fbdev \
  x11-xserver-utils \
  xinit \
  openbox \
  unclutter \
  xdotool
log "Display packages installed"

# ── 3. Chromium ───────────────────────────────────────────────────────────────
info "Installing Chromium..."
apt-get install -y --no-install-recommends chromium-browser 2>/dev/null || \
apt-get install -y --no-install-recommends chromium 2>/dev/null || \
err "Could not install Chromium. Run: sudo apt-get install chromium-browser"
log "Chromium installed"

# ── 4. Audio ──────────────────────────────────────────────────────────────────
info "Installing audio packages..."
apt-get install -y --no-install-recommends \
  alsa-utils \
  libasound2-dev \
  pulseaudio \
  pulseaudio-utils \
  libpulse-dev
log "Audio packages installed"
usermod -aG audio "${PI_USER}"

# ── 5. MPV ────────────────────────────────────────────────────────────────────
info "Installing mpv..."
apt-get install -y --no-install-recommends mpv socat 2>/dev/null || {
  warn "mpv not in default repos, trying with contrib/non-free..."
  # Add non-free to sources if needed
  if ! grep -q "non-free" /etc/apt/sources.list 2>/dev/null; then
    sed -i 's/main$/main contrib non-free non-free-firmware/' /etc/apt/sources.list
    apt-get update -qq
  fi
  apt-get install -y --no-install-recommends mpv socat
}
command -v mpv &>/dev/null || err "mpv failed to install"
log "mpv installed: $(mpv --version | head -1)"

# ── 6. Python ─────────────────────────────────────────────────────────────────
info "Installing Python..."
apt-get install -y --no-install-recommends \
  python3 python3-pip python3-venv python3-dev \
  libssl-dev libffi-dev build-essential
log "Python installed: $(python3 --version)"

# ── 7. Nginx ──────────────────────────────────────────────────────────────────
info "Installing nginx..."
apt-get install -y --no-install-recommends nginx
log "nginx installed"

# ── 8. Avahi (mDNS) ───────────────────────────────────────────────────────────
info "Installing Avahi for network discovery..."
apt-get install -y --no-install-recommends \
  avahi-daemon \
  libavahi-client-dev
systemctl enable avahi-daemon
systemctl start avahi-daemon
log "Avahi installed"

# ── 9. shairport-sync (AirPlay) ───────────────────────────────────────────────
info "Installing shairport-sync..."

# Try apt first (available on Pi OS Bookworm)
if apt-get install -y --no-install-recommends shairport-sync 2>/dev/null; then
  log "shairport-sync installed from apt"
elif command -v shairport-sync &>/dev/null; then
  log "shairport-sync already installed"
else
  # Fall back to building from source
  warn "shairport-sync not in apt, building from source (takes ~10 min)..."
  apt-get install -y --no-install-recommends \
    autoconf automake libtool pkg-config \
    libpopt-dev libconfig-dev libssl-dev \
    libavahi-client-dev libsoxr-dev libpulse-dev \
    libglib2.0-dev libasound2-dev build-essential
  apt-get install -y xmltoman 2>/dev/null || true

  SHAIRPORT_VER="4.3.2"
  cd /tmp
  rm -rf "shairport-sync-${SHAIRPORT_VER}"
  wget -q "https://github.com/mikebrady/shairport-sync/archive/refs/tags/${SHAIRPORT_VER}.tar.gz"
  tar xf "${SHAIRPORT_VER}.tar.gz"
  cd "shairport-sync-${SHAIRPORT_VER}"
  autoreconf -fi

  BACKENDS="--with-avahi --with-ssl=openssl --with-metadata --with-systemd"
  pkg-config --exists alsa 2>/dev/null && BACKENDS="--with-alsa $BACKENDS"
  pkg-config --exists libpulse 2>/dev/null && BACKENDS="--with-pa $BACKENDS"
  pkg-config --exists soxr 2>/dev/null && BACKENDS="--with-soxr $BACKENDS"

  ./configure --sysconfdir=/etc $BACKENDS
  make -j4
  make install
  cd /tmp
  rm -rf "shairport-sync-${SHAIRPORT_VER}" "${SHAIRPORT_VER}.tar.gz"
  log "shairport-sync built and installed"
fi

# Verify the systemd unit exists before trying to enable it
if ! systemctl list-unit-files | grep -q shairport-sync; then
  warn "shairport-sync systemd unit not found - creating it manually..."
  cat > /etc/systemd/system/shairport-sync.service << SSUNIT
[Unit]
Description=Shairport Sync - AirPlay Audio Receiver
After=sound.target avahi-daemon.service network-online.target
Wants=avahi-daemon.service network-online.target

[Service]
ExecStart=/usr/local/bin/shairport-sync
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SSUNIT
  systemctl daemon-reload
fi

# Configure shairport-sync
DEVICE_NAME="PlexPi"
cat > /etc/shairport-sync.conf << SHAIRCONF
general = {
  name = "${DEVICE_NAME}";
  output_backend = "pa";
};
metadata = {
  enabled = "yes";
  include_cover_art = "yes";
  pipe_name = "/tmp/shairport-sync-metadata";
  pipe_timeout = 5000;
};
pa = {
  application_name = "PlexPi";
};
SHAIRCONF

systemctl daemon-reload
systemctl enable shairport-sync 2>/dev/null || warn "Could not enable shairport-sync service"
systemctl restart shairport-sync 2>/dev/null || warn "shairport-sync did not start - check after reboot"
log "AirPlay configured - device name: '${DEVICE_NAME}'"

# ── 10. Deploy Python backend ─────────────────────────────────────────────────
info "Deploying Python backend..."
mkdir -p "${PLEXPI_DIR}/backend"
cp "${SCRIPT_DIR}/backend/app.py" "${PLEXPI_DIR}/backend/"
cp "${SCRIPT_DIR}/backend/requirements.txt" "${PLEXPI_DIR}/backend/"

python3 -m venv "${PLEXPI_DIR}/venv"
"${PLEXPI_DIR}/venv/bin/pip" install -q --upgrade pip
"${PLEXPI_DIR}/venv/bin/pip" install -q \
  flask flask-cors plexapi requests gunicorn
log "Python backend deployed"

# ── 11. Deploy frontend ───────────────────────────────────────────────────────
info "Deploying frontend..."
mkdir -p /var/www/plexpi
cp "${SCRIPT_DIR}/frontend/index.html" /var/www/plexpi/
log "Frontend deployed"

# ── 12. systemd service for backend ──────────────────────────────────────────
info "Creating PlexPi systemd service..."
cat > /etc/systemd/system/plexpi.service << SVCEOF
[Unit]
Description=PlexPi Music Player Backend
After=network.target sound.target pulseaudio.service

[Service]
User=${PI_USER}
WorkingDirectory=${PLEXPI_DIR}/backend
ExecStart=${PLEXPI_DIR}/venv/bin/gunicorn --bind 127.0.0.1:8080 --workers 1 --threads 4 --timeout 60 app:app
Restart=always
RestartSec=5
Environment=HOME=${PI_HOME}
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
SVCEOF

systemctl daemon-reload
systemctl enable plexpi
systemctl restart plexpi
log "PlexPi backend service started"

# ── 13. Nginx config ──────────────────────────────────────────────────────────
info "Configuring nginx..."
cat > /etc/nginx/sites-available/plexpi << 'NGINXEOF'
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;
    root /var/www/plexpi;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
        add_header Cache-Control "no-cache";
    }

    location /api/ {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_set_header Host $host;
        proxy_read_timeout 300;
        proxy_buffering off;
    }
}
NGINXEOF

rm -f /etc/nginx/sites-enabled/default
ln -sf /etc/nginx/sites-available/plexpi /etc/nginx/sites-enabled/plexpi
nginx -t && systemctl restart nginx
log "nginx configured"

# ── 14. Auto-login on tty1 ────────────────────────────────────────────────────
info "Configuring auto-login on tty1..."
mkdir -p /etc/systemd/system/getty@tty1.service.d
cat > /etc/systemd/system/getty@tty1.service.d/autologin.conf << AUTOLOGIN
[Service]
ExecStart=
ExecStart=-/sbin/agetty --autologin ${PI_USER} --noclear %I \$TERM
AUTOLOGIN
systemctl daemon-reload
log "Auto-login configured for ${PI_USER} on tty1"

# ── 15. Openbox autostart (kiosk) ─────────────────────────────────────────────
info "Configuring Openbox kiosk autostart..."
mkdir -p "${PI_HOME}/.config/openbox"
cat > "${PI_HOME}/.config/openbox/autostart" << 'KIOSKEOF'
# Disable screen blanking and power saving
xset s off &
xset -dpms &
xset s noblank &

# Hide mouse cursor after 3s idle
unclutter -idle 3 -root &

# Wait for network and backend to be ready
sleep 4

# Fix any Chromium crash flags from previous session
PREFS="${HOME}/.config/chromium/Default/Preferences"
if [ -f "$PREFS" ]; then
  sed -i 's/"exited_cleanly":false/"exited_cleanly":true/g' "$PREFS"
  sed -i 's/"exit_type":"Crashed"/"exit_type":"Normal"/g' "$PREFS"
fi

# Launch Chromium in kiosk mode
chromium-browser \
  --kiosk \
  --noerrdialogs \
  --disable-infobars \
  --disable-session-crashed-bubble \
  --disable-features=TranslateUI \
  --disable-restore-session-state \
  --no-first-run \
  --touch-events=enabled \
  --disable-pinch \
  --overscroll-history-navigation=0 \
  --check-for-update-interval=31536000 \
  --disable-translate \
  --password-store=basic \
  "http://localhost" &
KIOSKEOF

chown -R "${PI_USER}:${PI_USER}" "${PI_HOME}/.config"
log "Openbox kiosk configured"

# ── 16. Auto-start X on login ─────────────────────────────────────────────────
info "Configuring X auto-start on tty1 login..."

# Write to profile.d so it works regardless of shell config
cat > /etc/profile.d/plexpi-kiosk.sh << 'PROFILEOF'
if [ -z "$DISPLAY" ] && [ "$(tty)" = "/dev/tty1" ]; then
  exec startx /usr/bin/openbox-session -- :0 vt1 -nocursor 2>/tmp/xorg.log
fi
PROFILEOF

chmod +x /etc/profile.d/plexpi-kiosk.sh
log "X auto-start configured"

# ── 17. PulseAudio user service ───────────────────────────────────────────────
info "Configuring PulseAudio..."
# Ensure PulseAudio starts as user service on login
mkdir -p "${PI_HOME}/.config/pulse"
cat > "${PI_HOME}/.config/pulse/client.conf" << 'PULSEEOF'
autospawn = yes
daemon-binary = /usr/bin/pulseaudio
PULSEEOF
chown -R "${PI_USER}:${PI_USER}" "${PI_HOME}/.config/pulse"
log "PulseAudio configured"

# ── Done ──────────────────────────────────────────────────────────────────────
PI_IP=$(hostname -I | awk '{print $1}')
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║         Setup Complete! 🎵               ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
echo ""
echo -e "  Web UI:        ${YELLOW}http://${PI_IP}${NC}"
echo -e "  AirPlay name:  ${YELLOW}${DEVICE_NAME}${NC}"
echo ""
echo -e "  Service status:"
echo -e "    plexpi:          $(systemctl is-active plexpi)"
echo -e "    shairport-sync:  $(systemctl is-active shairport-sync)"
echo -e "    nginx:           $(systemctl is-active nginx)"
echo ""
echo -e "  ${YELLOW}Run this to reboot into kiosk mode:${NC}"
echo -e "  ${GREEN}sudo reboot${NC}"
echo ""
